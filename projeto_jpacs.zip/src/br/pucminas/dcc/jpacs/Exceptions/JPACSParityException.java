package br.pucminas.dcc.jpacs.Exceptions;

/**
 * Created by Junior on 01/10/16.
 */
public class JPACSParityException extends Exception {
    public JPACSParityException(String Msg) {
        super(Msg);
    }
}